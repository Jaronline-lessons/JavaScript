(function () {
    // Start coding here
})();