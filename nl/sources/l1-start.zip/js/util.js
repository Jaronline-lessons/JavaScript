/**
 * Sets the output of the calculator
 * @param {string} output
 * @author Jaronline
 */
function setCalculatorOutput(output) {
    document.getElementById("calculator-output").innerText = output;
}

/**
 * Gets the buttons of the calculator
 * @returns {HTMLButtonElement[]}
 */
function getCalculatorButtons() {
    return [...document.querySelectorAll(".calculator-button")];
}