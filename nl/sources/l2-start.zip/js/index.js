(function () {
    // Start coding here
    /*
    Deze code laat de verschillende data types zien in de console.
    Dit is handig om te weten welke data types je kan gebruiken in JavaScript.
    */
    console.log(typeof "Hallo Wereld"); // string
    console.log(typeof 42); // number
    console.log(typeof true); // boolean
    console.log(typeof null); // object
    console.log(typeof undefined); // undefined
})();