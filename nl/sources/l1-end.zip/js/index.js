(function () {
    // Start coding here
    /*
    Deze code laat de verschillende data types zien in de console.
    Dit is handig om te weten welke data types je kan gebruiken in JavaScript.
    */
    console.log("Hallo Wereld"); // string
    console.log(42); // number
    console.log(true); // boolean
    console.log(null); // object
    console.log(undefined); // undefined
})();