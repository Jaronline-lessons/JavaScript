(function() {
    // Start coding here
})();